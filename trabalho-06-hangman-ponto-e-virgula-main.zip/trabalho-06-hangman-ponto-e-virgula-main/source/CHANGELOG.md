# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/) 
and this project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]
### Added
* Apr-18th:
    - Refactoring the project to include the game class (game loop).

* Mar-19th
    - To avoid circular reference, I created a commom header.
